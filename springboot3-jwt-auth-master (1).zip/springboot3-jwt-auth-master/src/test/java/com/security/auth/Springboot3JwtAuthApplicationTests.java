package com.security.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot3JwtAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
